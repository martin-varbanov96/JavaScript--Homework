﻿# 6.CountNumberOfDiv


