﻿function main(input){
   
    var first = parseInt(input[0]);
    var second = parseInt(input[1]);

    console.log(first+second);

}

main(['155', '65']);