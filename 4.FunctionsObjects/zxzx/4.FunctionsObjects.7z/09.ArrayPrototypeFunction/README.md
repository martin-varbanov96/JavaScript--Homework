﻿# 09.ArrayPrototypeFunction


