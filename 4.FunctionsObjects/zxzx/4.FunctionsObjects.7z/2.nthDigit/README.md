﻿# 2.nthDigit


